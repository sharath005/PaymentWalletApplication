package com.trg.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trg.boot.entity.BenificiaryDetails;
import com.trg.boot.entity.Wallet;

public interface BenificiaryRepository  extends  JpaRepository<BenificiaryDetails, Integer> {

	List<BenificiaryDetails> findByWallet(Wallet wallet);
	BenificiaryDetails findById(int id);

}
