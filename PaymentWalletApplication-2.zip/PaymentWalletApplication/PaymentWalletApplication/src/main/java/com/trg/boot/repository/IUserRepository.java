package com.trg.boot.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.trg.boot.entity.Customer;

@Repository
public interface IUserRepository extends JpaRepository<Customer,String> {

	Optional<Customer> findByPassword(String password);
    
	Customer findByWallet(int walletid);
	
	


}
