package com.trg.boot.exceptionhandler;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.trg.boot.exceptions.InValidLoginUserException;

@ControllerAdvice
public class LoginUserExceptionHandler {
   
	
	@ExceptionHandler(InValidLoginUserException.class)
	public ResponseEntity<?> handleEmployeeDataError(InValidLoginUserException il){
		
		Map<String,Object> errors=new LinkedHashMap<>();
		
		errors.put("error","Not a Valid User Credentials");
		errors.put("message", il.getMessage());
		errors.put("timestamp", LocalDate.now());
		
		return new ResponseEntity<Object>(errors,HttpStatus.NOT_FOUND);
		
	}
	
	
}
