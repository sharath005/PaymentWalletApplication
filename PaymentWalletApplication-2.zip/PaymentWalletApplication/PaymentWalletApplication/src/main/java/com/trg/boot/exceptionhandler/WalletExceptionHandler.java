package com.trg.boot.exceptionhandler;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.trg.boot.exceptions.InsufficientBalanceException;
import com.trg.boot.exceptions.InvalidInputException;

@ControllerAdvice
public class WalletExceptionHandler {
   
	@ExceptionHandler(InvalidInputException.class)
	public ResponseEntity<?> invalidInputError(InvalidInputException il){
		
		Map<String,Object> errors=new LinkedHashMap<>();
		
		errors.put("error","Not a Valid input");
		errors.put("message", il.getMessage());
		errors.put("timestamp", LocalDate.now());
		
		return new ResponseEntity<Object>(errors,HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(InsufficientBalanceException.class)
	public ResponseEntity<?> insufficientbalanceError(InsufficientBalanceException il){
		
		Map<String,Object> errors=new LinkedHashMap<>();
		
		errors.put("error","Insufficient Balance");
		errors.put("message", il.getMessage());
		errors.put("timestamp", LocalDate.now());
		
		return new ResponseEntity<Object>(errors,HttpStatus.NOT_FOUND);
		
	}
	
	
}
