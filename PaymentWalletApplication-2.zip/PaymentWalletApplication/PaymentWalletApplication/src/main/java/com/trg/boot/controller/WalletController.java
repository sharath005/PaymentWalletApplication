package com.trg.boot.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trg.boot.entity.Customer;
import com.trg.boot.entity.Wallet;
import com.trg.boot.serviceinterface.IWalletService;

@RestController
@RequestMapping("wallet")
public class WalletController {

	@Autowired
	IWalletService iwc;

	@PutMapping("createaccount/{name}/{mobileno}/{amount}")
	public ResponseEntity<?> createAccount(@PathVariable("name") String name, @PathVariable("mobileno") String mobileno,
			@PathVariable("amount") BigDecimal amount) {

		Customer c = iwc.createAccount(name, mobileno, amount);

		if (c == null)
			return new ResponseEntity<>("Cannot be Created as no account with the mobileno present or account has already been present",
					HttpStatus.NOT_FOUND);
		else {
			return new ResponseEntity<>(c, HttpStatus.OK);
		}

	}

	@GetMapping("/showbalance/{mobileno}")
	public ResponseEntity<?> showBalance(@PathVariable String mobileno) {

		BigDecimal bal = iwc.showBalance(mobileno);
        
		if (bal == null)
			return new ResponseEntity<>("Cannot show the balance as no customer is present or wallet is present",
					HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(bal, HttpStatus.ACCEPTED);

	}

	@GetMapping("/customers")
	public ResponseEntity<?> getListOfCustomer() {

		List<Customer> l = iwc.getList();

		if (l == null)
			return new ResponseEntity<>("No Customers", HttpStatus.NOT_FOUND);
		else {
			return new ResponseEntity<>(l, HttpStatus.OK);
		}

	}

	@PutMapping("/updateaccount")
	public ResponseEntity<?> updateAccount(@RequestBody Customer customer) {
		Customer c = iwc.updateAccount(customer);
		if (c == null)
			return new ResponseEntity<>("Cannot Update the Account as customer is not found", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(c, HttpStatus.OK);
	}

	@PutMapping("/addmoney/{amount}/{walletid}")
	public ResponseEntity<?> addMoney(@PathVariable double amount,@PathVariable int walletid) {

		Wallet w = iwc.addMoney(walletid, amount);
		if (w == null)
			return new ResponseEntity<>("cannot add money as wallet not present", HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(w, HttpStatus.OK);

	}
	
	@PutMapping("/bankfundtransfer/{srcMobileNo}/{destMobileNo}/{amount}")
	public Customer fundTransfer(@PathVariable String srcMobileNo,@PathVariable String destMobileNo,@PathVariable BigDecimal amount) {
		return iwc.fundTransfer(srcMobileNo, destMobileNo, amount);
		
	}
	
	@PutMapping("/withdrawamount/{mobileNo}/{amount}")
	public Customer withdrawAmount(@PathVariable String mobileNo, @PathVariable BigDecimal amount) {
		return iwc.withdrawAmount(mobileNo, amount);
	}

}
