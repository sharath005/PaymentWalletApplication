package com.trg.boot.serviceinterface;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.trg.boot.entity.Customer;
import com.trg.boot.entity.Wallet;

public interface IWalletService {
   
	public Customer createAccount(String name ,String mobileno, BigDecimal amount);
	public BigDecimal showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount);
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
	public List<Customer> getList();
	public Customer updateAccount(Customer customer);
	public Wallet addMoney(int walletid, double amount);
}
