package com.trg.boot.exceptionhandler;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.trg.boot.exceptions.NoPaymentFoundException;

@ControllerAdvice
public class BillPaymentExceptionHandler {
     
	@ExceptionHandler(NoPaymentFoundException.class)
	public ResponseEntity<?> handleEmployeeDataError(NoPaymentFoundException np){
		
		Map<String,Object> errors=new LinkedHashMap<>();
		
		errors.put("error","Invalid Bill Payment Id.Check with the bill id");
		errors.put("message", np.getMessage());
		errors.put("timestamp", LocalDate.now());
		
		return new ResponseEntity<Object>(errors,HttpStatus.NOT_FOUND);
		
	}
	
	
	
}
