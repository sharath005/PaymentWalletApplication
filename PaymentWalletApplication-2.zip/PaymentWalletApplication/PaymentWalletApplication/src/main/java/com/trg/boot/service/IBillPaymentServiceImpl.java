package com.trg.boot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trg.boot.entity.BillPayment;
import com.trg.boot.repository.IBillPaymentRepository;
import com.trg.boot.repository.WalletRepository;
import com.trg.boot.serviceinterface.IBillPaymentService;

@Service
public class IBillPaymentServiceImpl implements IBillPaymentService {
    
	@Autowired
	IBillPaymentRepository ibrepo;
	
	@Autowired
	WalletRepository wrepo;
	
	
	@Override
	public BillPayment addBillPayment(BillPayment payment) {	
		boolean b=wrepo.existsById(payment.getWallet().getWalletId());
		if(!b) {
			return null;
		}
		BillPayment bill=new BillPayment();
		bill.setBillId(payment.getBillId());
		bill.setBilltype(payment.getBilltype());
		bill.setAmount(payment.getAmount());
		bill.setPaymentDate(payment.getPaymentDate());
		bill.setWallet(wrepo.findById(payment.getWallet().getWalletId()).get());
		return ibrepo.save(bill);
	}

	@Override
	public BillPayment viewBillPayment(int paymentid) {
		
		boolean b=ibrepo.existsById(paymentid);
		if(!b) {
			return null;
		}
		else {
		   return ibrepo.findById(paymentid).get();
		}
		
		
	}

}
