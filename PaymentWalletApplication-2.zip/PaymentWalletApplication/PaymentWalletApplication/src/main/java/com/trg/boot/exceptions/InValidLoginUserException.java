package com.trg.boot.exceptions;

public class InValidLoginUserException extends RuntimeException {
        
	public InValidLoginUserException(String msg){
		super(msg);
	}
	
	
}
