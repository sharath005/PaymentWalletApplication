package com.trg.boot.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trg.boot.entity.BankAccount;
import com.trg.boot.entity.Customer;
import com.trg.boot.entity.Wallet;
import com.trg.boot.exceptions.InsufficientBalanceException;
import com.trg.boot.exceptions.InvalidInputException;
import com.trg.boot.repository.AccountRepository;
import com.trg.boot.repository.IUserRepository;
import com.trg.boot.repository.WalletRepository;
import com.trg.boot.serviceinterface.IWalletService;

@Service
public class IWalletServiceImpl implements IWalletService {

	@Autowired
	IUserRepository iurepo;

	@Autowired
	WalletRepository wrepo;

	@Autowired
	AccountRepository arepo;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {

		Optional<Customer> c = iurepo.findById(mobileno);
		if (!c.isPresent()) {
			throw new InvalidInputException("No customer found for the mobile no :"+mobileno);		
		} else if (c.get().getWallet() == null) {
			Wallet w = new Wallet();
			w.setBalance(amount);
			wrepo.save(w);
			c.get().setWallet(w);
			iurepo.save(c.get());
			return c.get();
		} else {
			throw new InvalidInputException("Wallet is already Presnt for the mobileno");
		}

	}

	@Override
	public BigDecimal showBalance(String mobileno) {
		boolean b = iurepo.existsById(mobileno);
		if (!b) {
			throw new InvalidInputException("mobileno does not exists");
		} else {
			Customer c = iurepo.getOne(mobileno);
			Wallet w = c.getWallet();
			return w.getBalance();
		}
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		boolean s = iurepo.existsById(sourceMobileNo);
		boolean t = iurepo.existsById(targetMobileNo);

		double damount = amount.doubleValue();

		if (!s || !t)
			throw new InvalidInputException("Enter the correct mobile no detatisl");
		else {

			Customer csrc = iurepo.findById(sourceMobileNo).get();
			Customer cdes = iurepo.findById(targetMobileNo).get();
			BankAccount src = arepo.findByWallet(csrc.getWallet());
			BankAccount dest = arepo.findByWallet(cdes.getWallet());

			if (src != null && dest != null) {
				if (src.getBalance() < damount)
					throw new InsufficientBalanceException("balance amount is less to send");
				else {
					dest.setBalance(dest.getBalance() + damount);
					src.setBalance(src.getBalance() - damount);
					arepo.save(src);
					arepo.save(dest);
					return cdes;
				}
			} else {
				throw new InvalidInputException("Bank Account not Available");

			}

		}

	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		boolean s = iurepo.existsById(mobileNo);
		if (!s) {
			throw new InvalidInputException("Enter the Correct Mobile No");
		} else {
			Customer csrc = iurepo.findById(mobileNo).get();
			Wallet w = csrc.getWallet();
			BigDecimal bal = w.getBalance();
			if (bal.doubleValue() < amount.doubleValue()) {
				throw new InsufficientBalanceException("insufficient balance");
			} else {
				w.setBalance(w.getBalance().subtract(amount));
				wrepo.save(w);
				return csrc;
			}
		}
	}

	@Override
	public List<Customer> getList() {
		return iurepo.findAll();
	}

	@Override
	public Customer updateAccount(Customer customer) {
		Optional<Customer> cb = iurepo.findByPassword(customer.getPassword());
		if (cb.isEmpty())
			throw new InvalidInputException("Enter the Correct Customer password");
		else {
			Customer c=cb.get();
			//c.setMobileNo(customer.getMobileNo());
			c.setName(customer.getName());
			c.setPassword(customer.getPassword());
			iurepo.save(c);
			return c;
		}
	}

	@Override
	public Wallet addMoney(int walletid, double amount) {
		boolean b = wrepo.findById(walletid).isPresent();

		if (!b)
			throw new InvalidInputException("Wallet id not Present enter the correct wallet id");
		else {
			Wallet wallet = wrepo.findById(walletid).get();
			BigDecimal amt = new BigDecimal(amount);
			wallet.setBalance(amt.add(wallet.getBalance()));
			wrepo.save(wallet);
			return wallet;
		}

	}

}
