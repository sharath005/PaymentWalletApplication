package com.trg.boot.exceptions;

public class InsufficientBalanceException extends RuntimeException {
     public InsufficientBalanceException(String msg) {
    	 super(msg);
     }
}
