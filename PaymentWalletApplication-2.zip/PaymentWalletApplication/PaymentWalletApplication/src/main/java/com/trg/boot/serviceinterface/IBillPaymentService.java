package com.trg.boot.serviceinterface;

import com.trg.boot.entity.BillPayment;

public interface IBillPaymentService {
     
	public BillPayment addBillPayment(BillPayment payment);
	public BillPayment viewBillPayment(int paymentid);
}
