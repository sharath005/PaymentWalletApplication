package com.trg.boot.exceptions;

public class NoPaymentFoundException extends RuntimeException {
     
	public NoPaymentFoundException(String msg){
		super(msg);
	}
}
