package com.trg.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trg.boot.entity.BenificiaryDetails;
import com.trg.boot.entity.Customer;
import com.trg.boot.serviceinterface.BenificiaryService;

@RestController
@RequestMapping("benificiary")
public class BenificiaryController {
	@Autowired
	BenificiaryService benificiaryService;

	@GetMapping("viewbenificiary/{bd}")
	public BenificiaryDetails viewBenificiary(@PathVariable("bd") int bd) {
		return benificiaryService.viewBenificiary(bd);
	}
	@PutMapping("updatebenificiary")
	public ResponseEntity<?> updateBenificiary(@RequestBody BenificiaryDetails bd) {
		return new ResponseEntity<>(benificiaryService.updateBenificiary(bd),HttpStatus.OK);
	}

	@PostMapping("addbenificiary")
	public ResponseEntity<?> addBenificiary(@RequestBody BenificiaryDetails bd) {
		return new ResponseEntity<>(benificiaryService.addBenificiary(bd),HttpStatus.OK);
	}
	@DeleteMapping("deletebenificiary/{bd}")
	public ResponseEntity<?> deleteBenificiary(@PathVariable("bd") int bd) {
		return new ResponseEntity<>(benificiaryService.deleteBenificiary(bd),HttpStatus.OK);
	}
	
	@GetMapping("viewall/benificiary/{bd}")
	public ResponseEntity<?> viewAllBenificiary(@PathVariable("bd") int bd) {
		return new ResponseEntity<>(benificiaryService.viewAllBenificiary(bd),HttpStatus.OK);
	}
	
	
}
