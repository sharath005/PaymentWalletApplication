package com.trg.boot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trg.boot.entity.Customer;
import com.trg.boot.exceptions.InValidLoginUserException;
import com.trg.boot.repository.IUserRepository;
import com.trg.boot.serviceinterface.IUserService;

@Service
public class IUserServiceImpl implements IUserService {
    
	@Autowired
	private IUserRepository irepo;
	
	@Override
	public Customer validateLoginUser(String mobileNumber, String password) {
		
		Optional<Customer> c=irepo.findById(mobileNumber);
		Optional<Customer>p=irepo.findByPassword(password);
		
		
		
		if(c.isPresent()&&p.isPresent()) {
			System.out.println(c);
			return c.get();
		}
		else {
			throw new InValidLoginUserException("Check with your Login Credentials");
		}
		
	}
	


	@Override
	public List<Customer> getAllCustomer() {
		return irepo.findAll();
		
	}


}
