package com.trg.boot.serviceinterface;

import java.util.List;

import com.trg.boot.entity.BenificiaryDetails;
import com.trg.boot.entity.Customer;


public interface BenificiaryService {
	
public List<BenificiaryDetails> addBenificiary(BenificiaryDetails bd);
public List<BenificiaryDetails> updateBenificiary(BenificiaryDetails bd);
public String deleteBenificiary(int bd);
public BenificiaryDetails viewBenificiary(int bd);
public List<BenificiaryDetails> viewAllBenificiary(int w);
}