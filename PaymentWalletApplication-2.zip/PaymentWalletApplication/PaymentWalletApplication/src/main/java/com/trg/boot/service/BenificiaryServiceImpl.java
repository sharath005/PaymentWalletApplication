package com.trg.boot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trg.boot.entity.BenificiaryDetails;
import com.trg.boot.entity.Customer;
import com.trg.boot.entity.Wallet;
import com.trg.boot.exceptions.InvalidInputException;
import com.trg.boot.repository.BenificiaryRepository;
import com.trg.boot.repository.IUserRepository;
import com.trg.boot.repository.WalletRepository;
import com.trg.boot.serviceinterface.BenificiaryService;

@Service
public class BenificiaryServiceImpl implements BenificiaryService {
	@Autowired
	BenificiaryRepository brepo;

	@Autowired
	WalletRepository wrepo;

	@Autowired
	IUserRepository iurepo;

	@Override
	public List<BenificiaryDetails> addBenificiary(BenificiaryDetails bd) {
		boolean b = brepo.existsById(bd.getBenificiaryId());
		if (b)
			throw new InvalidInputException("Benificiary id " + bd.getBenificiaryId() + " Already present");

		else {

			Wallet w = bd.getWallet();
			BenificiaryDetails bend = new BenificiaryDetails();
			bend.setBenificiaryId(bd.getBenificiaryId());
			bend.setMobileNumber(bd.getMobileNumber());
			bend.setName(bd.getName());
			Optional<Wallet> w1 = wrepo.findById(bd.getWallet().getWalletId());
			if (!w1.isPresent())
				throw new InvalidInputException("Wallet with the id not found ");
			bend.setWallet(w1.get());
			brepo.save(bend);
			return brepo.findByWallet(w);
		}
	}

	@Override
	public List<BenificiaryDetails> updateBenificiary(BenificiaryDetails bd) {
		return addBenificiary(bd);

	}

	@Override
	public String deleteBenificiary(int bd) {

		throw new InvalidInputException("Benificiary to be deleted for id " + bd + " not found");
	}

	@Override
	public BenificiaryDetails viewBenificiary(int bd) {

		if (!brepo.existsById(bd))
			throw new InvalidInputException("Benificiary with the id " + bd + " not present");
		else
			return brepo.findById(bd);

	}

	public List<BenificiaryDetails> viewAllBenificiary(int wid) {

		boolean b = wrepo.existsById(wid);

		if (!b)
		    throw new InvalidInputException("No Benificiary found with the wallet id "+wid);
		else {
			Wallet w = wrepo.findById(wid).get();
			return brepo.findByWallet(w);
		}

	}

}
