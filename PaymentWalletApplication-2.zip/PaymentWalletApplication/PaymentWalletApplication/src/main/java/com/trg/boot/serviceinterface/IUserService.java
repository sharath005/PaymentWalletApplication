package com.trg.boot.serviceinterface;

import java.util.List;
import java.util.Optional;

import com.trg.boot.entity.Customer;

public interface IUserService {
	
	public Customer validateLoginUser(String mobileNumber,String password);
	
	public List<Customer> getAllCustomer();

}
