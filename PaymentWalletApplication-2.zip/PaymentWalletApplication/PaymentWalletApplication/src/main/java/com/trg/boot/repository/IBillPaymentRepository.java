package com.trg.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trg.boot.entity.BillPayment;

@Repository
public interface IBillPaymentRepository extends JpaRepository<BillPayment,Integer> {

}
