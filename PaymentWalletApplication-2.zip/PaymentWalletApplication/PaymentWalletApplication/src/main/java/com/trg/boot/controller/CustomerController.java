package com.trg.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trg.boot.entity.Customer;
import com.trg.boot.exceptions.InValidLoginUserException;
import com.trg.boot.serviceinterface.IUserService;

@RestController
@RequestMapping("customers")
public class CustomerController {
	
	@Autowired
	private IUserService iuser;
	
	@GetMapping()
	public List<Customer> getCustomer(){
		return iuser.getAllCustomer();
	}
	
	@GetMapping("{mno}/{pass}")
	public ResponseEntity<Customer> validateUser(@PathVariable String mno,@PathVariable String pass){
		return new ResponseEntity<>(iuser.validateLoginUser(mno, pass),HttpStatus.OK);
		
	}
		
		
		
		
	

}
