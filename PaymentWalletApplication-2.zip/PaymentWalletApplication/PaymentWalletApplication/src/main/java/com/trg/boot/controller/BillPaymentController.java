package com.trg.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trg.boot.entity.BillPayment;
import com.trg.boot.exceptions.NoPaymentFoundException;
import com.trg.boot.service.IBillPaymentServiceImpl;

@RestController
@RequestMapping("billpayment")
public class BillPaymentController {

	@Autowired
	IBillPaymentServiceImpl ibi;

	@PutMapping()
	public ResponseEntity<?> addBillPayment(@RequestBody BillPayment payment) {
		if (ibi.addBillPayment(payment) == null) {
			return new ResponseEntity<>("Check with your wallet id or bill type",
					HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<>(ibi.addBillPayment(payment), HttpStatus.CREATED);
		}
	}

	@GetMapping("viewbill/{paymentid}")
	public ResponseEntity<?> viewBillPayment(@PathVariable("paymentid") int paymentid) {
		if (ibi.viewBillPayment(paymentid) == null) {
			throw new NoPaymentFoundException("No Bill Payment For the ID" + paymentid + "Found");
		} else {
			return new ResponseEntity<>(ibi.viewBillPayment(paymentid), HttpStatus.CREATED);
		}
	}

//	@GetMapping("viewbill/")
//	public ResponseEntity<?> viewBillPayment1(@RequestBody BillPayment payment) {
//
//		return new ResponseEntity<>(ibi.viewBillPayment(payment), HttpStatus.CREATED);
//	}

}
