package com.trg.boot;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.trg.boot.entity.Customer;
import com.trg.boot.repository.IBillPaymentRepository;
import com.trg.boot.repository.IUserRepository;

@SpringBootTest
public class WalletTests {
   
	@Autowired
	private IUserRepository irepo;
	
	@Autowired
	IBillPaymentRepository ibrepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void showBalance() {
		Customer c=irepo.findById("9845171221").get();
		assertEquals(50000.00,c.getWallet().getBalance());
	}
	
	
	
}
