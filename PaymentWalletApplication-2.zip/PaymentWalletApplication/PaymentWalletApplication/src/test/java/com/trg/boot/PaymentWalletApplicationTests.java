package com.trg.boot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.trg.boot.entity.BillPayment;
import com.trg.boot.entity.BillType;
import com.trg.boot.entity.Customer;
import com.trg.boot.entity.Wallet;
import com.trg.boot.repository.IBillPaymentRepository;
import com.trg.boot.repository.IUserRepository;

@SpringBootTest
class PaymentWalletApplicationTests {
    
	@Autowired
	private IUserRepository irepo;
	
	@Autowired
	IBillPaymentRepository ibrepo;
	
	@Test
	void contextLoads() {
	}
    
	@Test
	public void testgetLogin() {
		List<Customer> c=irepo.findAll();
		assertThat(c).size().isGreaterThan(0);
	}
	
	@Test
	public void testLogin() {
		Customer c=irepo.findById("9845171221").get();
		Customer p=irepo.findByPassword("Ab123").get();
		
		assertEquals("Raju",c.getName());
		assertEquals("9845171221",p.getMobileNo());
		assertEquals("Ab123", c.getPassword());
		
	}
	
	@Test
	public void testAddBill() {
		BillPayment b=new BillPayment();
		b.setBillId(1001);
		b.setBilltype(BillType.LPG);
		b.setAmount(5000.00);
		b.setPaymentDate(LocalDate.now());
		b.setWallet(new Wallet(2,new BigDecimal(50000)));
		ibrepo.save(b);
		
		assertNotNull(ibrepo.findById(b.getBillId()).get());
		
	}
	
	@Test
	public void testViewBill() {
		assertNotNull(ibrepo.findById(1001).get());
	}
	
	
}
